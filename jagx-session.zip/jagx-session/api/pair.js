const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  delay,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');

function sendChunk(res, obj) {
  res.write(JSON.stringify(obj) + '\n');
}

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => (data += c));
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

// Packages the whole session folder (creds + key stores) into one portable
// string. The session ID IS the credential — nothing is stored server-side
// after this request finishes.
function encodeSession(dir) {
  const files = {};
  for (const f of fs.readdirSync(dir)) {
    files[f] = fs.readFileSync(path.join(dir, f), 'utf-8');
  }
  const gz = zlib.gzipSync(JSON.stringify(files));
  return 'JAGX~' + gz.toString('base64');
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'POST only' });
    return;
  }

  let phone = '';
  try {
    const body = req.body && Object.keys(req.body).length ? req.body : JSON.parse((await readRawBody(req)) || '{}');
    phone = (body.phone || '').replace(/[^0-9]/g, '');
  } catch {
    res.status(400).json({ error: 'Invalid request body.' });
    return;
  }

  if (!phone || phone.length < 8) {
    res.status(400).json({ error: 'Enter a valid phone number with country code, digits only.' });
    return;
  }

  res.writeHead(200, {
    'Content-Type': 'application/x-ndjson',
    'Cache-Control': 'no-cache, no-transform',
  });

  const tmpDir = path.join(os.tmpdir(), `jagx-session-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  fs.mkdirSync(tmpDir, { recursive: true });

  let finished = false;
  const cleanup = () => {
    try {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    } catch {
      // best-effort cleanup only
    }
  };

  const overallTimeout = setTimeout(() => {
    if (finished) return;
    finished = true;
    sendChunk(res, { type: 'error', message: "Timed out waiting for the code to be entered. Please refresh and try again — enter the code as soon as it appears." });
    res.end();
    cleanup();
  }, 105000); // stays under the 120s function cap

  try {
    const { state, saveCreds } = await useMultiFileAuthState(tmpDir);
    const { version } = await fetchLatestBaileysVersion();
    const sock = makeWASocket({
      version,
      logger: pino({ level: 'silent' }),
      printQRInTerminal: false,
      auth: state,
      browser: ['JagX', 'Chrome', '1.0.0'],
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
      if (finished || update.connection !== 'open') return;
      finished = true;
      clearTimeout(overallTimeout);
      try {
        await delay(1500); // let the final creds write settle
        const sessionId = encodeSession(tmpDir);
        try {
          await sock.sendMessage(sock.user.id, {
            text: '✅ *JagX connected successfully!*\n\nYour session ID is ready on the website — paste it into your bot\'s .env as SESSION_ID and start it up. No more scanning needed.\n\n⚠️ Treat that ID like a password. Anyone who has it can fully control this WhatsApp account.',
          });
        } catch {
          // non-fatal — the session ID itself still made it back to the browser
        }
        sendChunk(res, { type: 'session', session: sessionId });
      } catch (e) {
        sendChunk(res, { type: 'error', message: 'Connected, but packaging the session failed: ' + e.message });
      }
      res.end();
      cleanup();
      try {
        sock.end();
      } catch {
        // ignore
      }
    });

    await delay(2000);
    if (!sock.authState.creds.registered) {
      const code = await sock.requestPairingCode(phone);
      sendChunk(res, { type: 'code', code });
    }
  } catch (e) {
    if (!finished) {
      finished = true;
      clearTimeout(overallTimeout);
      sendChunk(res, { type: 'error', message: e.message || 'Something went wrong requesting a pairing code.' });
      res.end();
      cleanup();
    }
  }
};
